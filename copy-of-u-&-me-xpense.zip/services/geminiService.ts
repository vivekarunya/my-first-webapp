
import { GoogleGenAI } from "@google/genai";
import { Expense } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getFinancialInsights(expenses: Expense[], income: number): Promise<string> {
  if (expenses.length === 0) return "Add some expenses to get smart financial insights!";

  const totalSpent = expenses.reduce((sum, e) => sum + e.amount, 0);
  const vivekSpent = expenses.filter(e => e.person === 'Vivek').reduce((s, e) => s + e.amount, 0);
  const shefaliSpent = expenses.filter(e => e.person === 'Shefali').reduce((s, e) => s + e.amount, 0);
  
  const expenseSummary = expenses.map(e => `${e.date}: ${e.name} (${e.category}) by ${e.person} - AED ${e.amount}`).join('\n');
  const savingsRate = income > 0 ? (((income - totalSpent) / income) * 100).toFixed(1) : "N/A";
  
  const prompt = `
    I have a list of our home expenses (U & Me) in UAE Dirhams (AED). 
    Monthly Income: AED ${income.toLocaleString()}
    Total spent: AED ${totalSpent.toFixed(2)}.
    Vivek's Portion: AED ${vivekSpent.toFixed(2)}
    Shefali's Portion: AED ${shefaliSpent.toFixed(2)}
    Current Savings Rate: ${savingsRate}%.

    Please analyze our spending habits and provide:
    1. A strategic analysis of our spending distribution between Vivek and Shefali.
    2. Two specific, actionable tips to increase our household savings rate.
    3. An encouraging closing statement for both of us.

    Keep it concise, friendly, and formatted in clean paragraphs or bullet points.
    
    Expenses:
    ${expenseSummary}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional household financial advisor for the 'U & Me Xpense' app. You are helping Shef and Vivek manage their shared expenses. All amounts are in UAE Dirhams (AED).",
        temperature: 0.7,
      }
    });

    return response.text || "I couldn't generate insights at the moment. Please try again later.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Unable to connect to the AI advisor. Please check your connection.";
  }
}
