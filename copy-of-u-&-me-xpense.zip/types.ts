
export enum Category {
  Food = 'Food',
  Transport = 'Transport',
  Bills = 'Bills',
  Entertainment = 'Entertainment',
  Health = 'Health',
  Shopping = 'Shopping',
  Others = 'Others'
}

export type Person = 'Vivek' | 'Shefali';

export interface Expense {
  id: string;
  name: string;
  category: Category;
  amount: number;
  date: string;
  person: Person;
}

export interface CategoryData {
  name: string;
  value: number;
}
