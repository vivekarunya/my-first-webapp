
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Expense, Category, Person } from './types';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';
import ExpenseCharts from './components/ExpenseCharts';
import SummaryCards from './components/SummaryCards';
import SmartInsights from './components/SmartInsights';
import DateRangeFilter from './components/DateRangeFilter';
import QuickEntry from './components/QuickEntry';
import IncomeInput from './components/IncomeInput';
import { Plus, LayoutDashboard, List, PieChart as PieChartIcon, CheckCircle2, Download, Upload, Heart, User, Users } from 'lucide-react';

const STORAGE_KEYS = {
  EXPENSES: 'shef_vivek_expenses_data',
  INCOME_VIVEK: 'shef_vivek_income_vivek',
  INCOME_SHEFALI: 'shef_vivek_income_shefali'
};

const App: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return parsed.map((ex: any) => ({ ...ex, person: ex.person || 'Vivek' }));
    } catch (e) {
      console.error("Persistence Load Error:", e);
      return [];
    }
  });

  const [incomeVivek, setIncomeVivek] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INCOME_VIVEK);
    return saved ? parseFloat(saved) : 0;
  });

  const [incomeShefali, setIncomeShefali] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INCOME_SHEFALI);
    return saved ? parseFloat(saved) : 0;
  });

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | undefined>(undefined);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'list'>('dashboard');
  const [filterPerson, setFilterPerson] = useState<Person | 'All'>('All');
  const [saveIndicator, setSaveIndicator] = useState(false);
  
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
    showSaveIndicator();
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INCOME_VIVEK, incomeVivek.toString());
    localStorage.setItem(STORAGE_KEYS.INCOME_SHEFALI, incomeShefali.toString());
    showSaveIndicator();
  }, [incomeVivek, incomeShefali]);

  const showSaveIndicator = () => {
    setSaveIndicator(true);
    const timer = setTimeout(() => setSaveIndicator(false), 2000);
    return () => clearTimeout(timer);
  };

  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = { ...expenseData, id: crypto.randomUUID() };
    setExpenses(prev => [newExpense, ...prev]);
    setIsFormOpen(false);
  };

  const handleQuickAdd = (name: string, amount: number, category: Category, date: string, person: Person) => {
    const newExpense: Expense = {
      id: crypto.randomUUID(),
      name,
      amount,
      category,
      date,
      person
    };
    setExpenses(prev => [newExpense, ...prev]);
  };

  const handleUpdateExpense = (expenseData: Omit<Expense, 'id'>) => {
    if (!editingExpense) return;
    setExpenses(prev => prev.map(ex => (ex.id === editingExpense.id ? { ...expenseData, id: ex.id } : ex)));
    setEditingExpense(undefined);
    setIsFormOpen(false);
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('Permanently delete this transaction?')) {
      setExpenses(prev => prev.filter(ex => ex.id !== id));
    }
  };

  const handleEditClick = (expense: Expense) => {
    setEditingExpense(expense);
    setIsFormOpen(true);
  };

  const handleExportData = () => {
    const data = {
      expenses,
      incomeVivek,
      incomeShefali,
      exportDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `u_and_me_xpense_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (json.expenses && Array.isArray(json.expenses)) {
          const importedExpenses = json.expenses.map((ex: any) => ({ ...ex, person: ex.person || 'Vivek' }));
          setExpenses(importedExpenses);
          if (typeof json.incomeVivek === 'number') setIncomeVivek(json.incomeVivek);
          if (typeof json.incomeShefali === 'number') setIncomeShefali(json.incomeShefali);
          alert('Data successfully restored from backup!');
        } else {
          alert('Invalid backup file format.');
        }
      } catch (err) {
        alert('Error parsing backup file.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const filteredExpenses = useMemo(() => {
    return expenses.filter(ex => {
      const startsAfter = startDate ? ex.date >= startDate : true;
      const endsBefore = endDate ? ex.date <= endDate : true;
      const matchesPerson = filterPerson === 'All' ? true : ex.person === filterPerson;
      return startsAfter && endsBefore && matchesPerson;
    });
  }, [expenses, startDate, endDate, filterPerson]);

  const totalSpent = useMemo(() => filteredExpenses.reduce((sum, ex) => sum + ex.amount, 0), [filteredExpenses]);
  const totalIncome = incomeVivek + incomeShefali;

  return (
    <div className="min-h-screen bg-blue-50/50 pb-24 md:pb-12 text-slate-900">
      {saveIndicator && (
        <div className="fixed top-6 right-6 z-[60] bg-indigo-600 text-white px-5 py-3 rounded-2xl text-sm font-bold flex items-center gap-3 shadow-2xl shadow-indigo-200 animate-in fade-in slide-in-from-top-4 duration-300">
          <CheckCircle2 className="w-5 h-5" />
          Saved to Local Storage
        </div>
      )}

      <input type="file" ref={fileInputRef} onChange={handleImportData} accept=".json" className="hidden" />

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-blue-100/50 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 bg-gradient-to-br from-indigo-600 to-rose-400 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 shrink-0">
              <Heart className="w-6 h-6 text-white fill-white/20" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none mb-1">U & Me Xpense</h1>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest hidden sm:block">Couple Financial Ledger</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center bg-blue-50/50 rounded-2xl p-1.5 border border-blue-100/50">
              <button onClick={handleExportData} className="px-3 py-2 hover:bg-white rounded-xl text-slate-600 hover:text-indigo-600 transition-all flex items-center gap-2 text-xs font-bold">
                <Download className="w-4 h-4" />
                <span className="hidden md:inline">Backup</span>
              </button>
              <button onClick={() => fileInputRef.current?.click()} className="px-3 py-2 hover:bg-white rounded-xl text-slate-600 hover:text-indigo-600 transition-all flex items-center gap-2 text-xs font-bold">
                <Upload className="w-4 h-4" />
                <span className="hidden md:inline">Restore</span>
              </button>
            </div>

            <button
              onClick={() => { setEditingExpense(undefined); setIsFormOpen(true); }}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-2xl font-black transition-all shadow-xl shadow-indigo-100 active:scale-95 text-sm"
            >
              <Plus className="w-5 h-5" />
              <span className="hidden xs:inline">Add New</span>
              <span className="xs:hidden">Add</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        {/* Quick Actions (Mobile) */}
        <div className="sm:hidden grid grid-cols-2 gap-4">
          <button onClick={handleExportData} className="flex items-center justify-center gap-2 p-4 bg-white border border-blue-100 rounded-2xl text-slate-600 font-bold text-xs shadow-sm">
            <Download className="w-4 h-4 text-indigo-500" />
            Export
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center gap-2 p-4 bg-white border border-blue-100 rounded-2xl text-slate-600 font-bold text-xs shadow-sm">
            <Upload className="w-4 h-4 text-rose-500" />
            Import
          </button>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Inputs Section */}
          <div className="lg:col-span-4 space-y-8">
            <IncomeInput 
              vivekIncome={incomeVivek} 
              shefaliIncome={incomeShefali}
              onUpdateVivek={setIncomeVivek}
              onUpdateShefali={setIncomeShefali}
            />
            <QuickEntry selectedDate={startDate === endDate ? startDate : ''} onSave={handleQuickAdd} />
          </div>

          {/* Filters Section */}
          <div className="lg:col-span-8">
            <DateRangeFilter 
              startDate={startDate} 
              endDate={endDate} 
              setStartDate={setStartDate} 
              setEndDate={setEndDate} 
              onReset={() => { setStartDate(''); setEndDate(''); }} 
              expenses={expenses} 
            />
          </div>
        </div>

        {/* Financial Highlights */}
        <SummaryCards expenses={filteredExpenses} total={totalSpent} income={totalIncome} />

        {/* View Selection & Person Filter */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex bg-white/60 backdrop-blur-sm p-1.5 rounded-2xl border border-blue-100/50 w-fit shadow-sm">
            <button 
              onClick={() => setActiveTab('dashboard')} 
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-black transition-all ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-500 hover:text-indigo-600 hover:bg-blue-50'}`}
            >
              <PieChartIcon className="w-4 h-4" />
              Dashboard
            </button>
            <button 
              onClick={() => setActiveTab('list')} 
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-black transition-all ${activeTab === 'list' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-500 hover:text-indigo-600 hover:bg-blue-50'}`}
            >
              <List className="w-4 h-4" />
              Activity Log
            </button>
          </div>

          {activeTab === 'list' && (
            <div className="flex bg-white p-1.5 rounded-2xl border border-slate-100 w-fit shadow-sm animate-in slide-in-from-right-4 duration-500">
              <button 
                onClick={() => setFilterPerson('All')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${filterPerson === 'All' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Users className="w-3.5 h-3.5" />
                Everyone
              </button>
              <button 
                onClick={() => setFilterPerson('Vivek')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${filterPerson === 'Vivek' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-indigo-600'}`}
              >
                <User className="w-3.5 h-3.5" />
                Vivek
              </button>
              <button 
                onClick={() => setFilterPerson('Shefali')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${filterPerson === 'Shefali' ? 'bg-rose-500 text-white shadow-md' : 'text-slate-400 hover:text-rose-500'}`}
              >
                <User className="w-3.5 h-3.5" />
                Shefali
              </button>
            </div>
          )}
        </div>

        {activeTab === 'dashboard' ? (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 animate-in fade-in duration-500">
            <div className="xl:col-span-8 space-y-8">
              <ExpenseCharts expenses={filteredExpenses} />
              <div className="hidden xl:block">
                <ExpenseList expenses={filteredExpenses.slice(0, 5)} onEdit={handleEditClick} onDelete={handleDeleteExpense} compact title="Recent Transactions" />
              </div>
            </div>
            <div className="xl:col-span-4">
              <SmartInsights expenses={filteredExpenses} income={totalIncome} />
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <ExpenseList 
              expenses={filteredExpenses} 
              onEdit={handleEditClick} 
              onDelete={handleDeleteExpense} 
              title={
                filterPerson === 'All' 
                  ? (startDate || endDate ? "Filtered Transactions" : "Complete Ledger")
                  : `${filterPerson}'s Activity`
              } 
            />
          </div>
        )}
      </main>

      {isFormOpen && (
        <ExpenseForm 
          expense={editingExpense} 
          onClose={() => setIsFormOpen(false)} 
          onSubmit={editingExpense ? handleUpdateExpense : handleAddExpense} 
        />
      )}

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-6 left-6 right-6 h-16 bg-slate-900/90 backdrop-blur-lg rounded-2xl md:hidden flex justify-around items-center px-4 z-[50] shadow-2xl border border-white/10 overflow-visible">
        <button 
          onClick={() => setActiveTab('dashboard')} 
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === 'dashboard' ? 'text-indigo-400 scale-110' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <LayoutDashboard className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Home</span>
        </button>

        <div className="relative -top-6">
          <button 
            onClick={() => { setEditingExpense(undefined); setIsFormOpen(true); }} 
            className="w-14 h-14 bg-indigo-600 rounded-full text-white shadow-2xl shadow-indigo-500 flex items-center justify-center ring-8 ring-blue-50/10 active:scale-90 transition-transform"
          >
            <Plus className="w-7 h-7" />
          </button>
        </div>

        <button 
          onClick={() => setActiveTab('list')} 
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === 'list' ? 'text-indigo-400 scale-110' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <List className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Log</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
