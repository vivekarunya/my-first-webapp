
import React from 'react';
import { Expense, Category } from '../types';
import { Edit2, Trash2, ShoppingCart, Truck, Receipt, Play, Activity, ShoppingBag, MoreHorizontal, User, Calendar as CalendarIcon } from 'lucide-react';

interface ExpenseListProps {
  expenses: Expense[];
  onEdit: (expense: Expense) => void;
  onDelete: (id: string) => void;
  compact?: boolean;
  title: string;
}

const getCategoryIcon = (category: Category) => {
  switch (category) {
    case Category.Food: return <ShoppingCart className="w-4 h-4" />;
    case Category.Transport: return <Truck className="w-4 h-4" />;
    case Category.Bills: return <Receipt className="w-4 h-4" />;
    case Category.Entertainment: return <Play className="w-4 h-4" />;
    case Category.Health: return <Activity className="w-4 h-4" />;
    case Category.Shopping: return <ShoppingBag className="w-4 h-4" />;
    default: return <MoreHorizontal className="w-4 h-4" />;
  }
};

const getCategoryColor = (category: Category) => {
  switch (category) {
    case Category.Food: return 'bg-emerald-100 text-emerald-600';
    case Category.Transport: return 'bg-blue-100 text-blue-600';
    case Category.Bills: return 'bg-amber-100 text-amber-600';
    case Category.Entertainment: return 'bg-purple-100 text-purple-600';
    case Category.Health: return 'bg-rose-100 text-rose-600';
    case Category.Shopping: return 'bg-indigo-100 text-indigo-600';
    default: return 'bg-slate-100 text-slate-600';
  }
};

const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, onEdit, onDelete, compact, title }) => {
  if (expenses.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-blue-100/50 p-12 text-center shadow-sm">
        <div className="bg-blue-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
          <MoreHorizontal className="w-10 h-10 text-blue-300" />
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2">No Transactions Yet</h3>
        <p className="text-slate-400 text-sm font-medium">Start logging your daily expenses to see the magic happen.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 overflow-hidden">
      <div className="px-6 py-6 border-b border-slate-50 flex items-center justify-between">
        <h2 className="text-lg font-black text-slate-900">{title}</h2>
        {compact && expenses.length > 5 && (
          <span className="text-xs text-indigo-600 font-black uppercase tracking-widest cursor-pointer hover:underline">View All</span>
        )}
      </div>
      
      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/80">
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</th>
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Member</th>
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Category</th>
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Date</th>
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Amount</th>
              <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {expenses.map((expense) => (
              <tr key={expense.id} className="hover:bg-indigo-50/20 transition-colors group">
                <td className="px-6 py-5">
                  <span className="font-bold text-slate-900 block truncate max-w-[200px]">{expense.name}</span>
                </td>
                <td className="px-6 py-5">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${expense.person === 'Vivek' ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-500'}`}>
                    {expense.person}
                  </span>
                </td>
                <td className="px-6 py-5">
                  <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold ${getCategoryColor(expense.category)}`}>
                    {getCategoryIcon(expense.category)}
                    {expense.category}
                  </span>
                </td>
                <td className="px-6 py-5">
                  <span className="text-sm font-semibold text-slate-500">{new Date(expense.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </td>
                <td className="px-6 py-5 text-right">
                  <span className="font-black text-slate-900">
                    <span className="text-[10px] text-slate-400 mr-1 uppercase">AED</span>
                    {expense.amount.toFixed(2)}
                  </span>
                </td>
                <td className="px-6 py-5 text-right">
                  <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onEdit(expense)}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDelete(expense.id)}
                      className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card List */}
      <div className="md:hidden divide-y divide-slate-50">
        {expenses.map((expense) => (
          <div key={expense.id} className="p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <h4 className="font-black text-slate-900 leading-tight">{expense.name}</h4>
                <div className="flex items-center gap-2">
                  <span className={`inline-flex px-2 py-0.5 rounded-md text-[9px] font-black uppercase ${expense.person === 'Vivek' ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-500'}`}>
                    {expense.person}
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1">
                    <CalendarIcon className="w-3 h-3" />
                    {new Date(expense.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>
              <div className="text-right">
                 <p className="font-black text-slate-900">
                    <span className="text-[9px] text-slate-400 mr-0.5 uppercase">AED</span>
                    {expense.amount.toFixed(2)}
                 </p>
                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold mt-1 ${getCategoryColor(expense.category)}`}>
                    {getCategoryIcon(expense.category)}
                    {expense.category}
                  </span>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
               <button
                  onClick={() => onEdit(expense)}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 rounded-xl text-xs font-black"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => onDelete(expense.id)}
                  className="flex items-center gap-2 px-4 py-2 bg-rose-50 text-rose-500 rounded-xl text-xs font-black"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpenseList;
