
import React, { useState } from 'react';
import { ShieldAlert, Check, Edit2 } from 'lucide-react';

interface ExpenseLimitInputProps {
  limit: number;
  onUpdateLimit: (val: number) => void;
}

const ExpenseLimitInput: React.FC<ExpenseLimitInputProps> = ({ limit, onUpdateLimit }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [value, setValue] = useState(limit.toString());

  const handleSave = () => {
    const num = parseFloat(value) || 0;
    onUpdateLimit(num);
    setIsEditing(false);
  };

  return (
    <div className="bg-white py-2 px-3 rounded-xl border border-blue-100 shadow-sm flex items-center justify-between gap-2">
      <div className="flex items-center gap-1.5 text-slate-700 shrink-0">
        <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
        <h3 className="font-bold text-[10px] uppercase tracking-tight">Limit</h3>
      </div>
      
      <div className="flex items-center gap-1.5 min-w-0">
        {isEditing ? (
          <div className="flex items-center gap-1">
            <div className="relative">
              <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-400">AED</span>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                autoFocus
                className="text-[11px] pl-7 pr-1 py-1 bg-blue-50 border border-blue-100 rounded-lg focus:ring-1 focus:ring-rose-500 outline-none w-20"
                onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              />
            </div>
            <button
              onClick={handleSave}
              className="p-1 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors"
            >
              <Check className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <div className="text-xs font-black text-slate-900 whitespace-nowrap">
              <span className="text-[9px] text-slate-400 mr-0.5">AED</span>
              {limit > 0 ? limit.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 }) : 'N/A'}
            </div>
            <button
              onClick={() => setIsEditing(true)}
              className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
            >
              <Edit2 className="w-2.5 h-2.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseLimitInput;
