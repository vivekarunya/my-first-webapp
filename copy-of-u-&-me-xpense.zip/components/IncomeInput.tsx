
import React, { useState } from 'react';
import { Banknote, Check, Edit2 } from 'lucide-react';

interface IncomeInputProps {
  vivekIncome: number;
  shefaliIncome: number;
  onUpdateVivek: (val: number) => void;
  onUpdateShefali: (val: number) => void;
}

const IncomeInput: React.FC<IncomeInputProps> = ({ vivekIncome, shefaliIncome, onUpdateVivek, onUpdateShefali }) => {
  const [editingPerson, setEditingPerson] = useState<'Vivek' | 'Shefali' | null>(null);
  const [tempValue, setTempValue] = useState('');

  const handleStartEdit = (person: 'Vivek' | 'Shefali', currentVal: number) => {
    setEditingPerson(person);
    setTempValue(currentVal.toString());
  };

  const handleSave = () => {
    const num = parseFloat(tempValue) || 0;
    if (editingPerson === 'Vivek') onUpdateVivek(num);
    else if (editingPerson === 'Shefali') onUpdateShefali(num);
    setEditingPerson(null);
  };

  const total = vivekIncome + shefaliIncome;

  return (
    <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 space-y-5">
      <div className="flex items-center gap-3">
        <div className="bg-emerald-50 p-2.5 rounded-2xl">
          <Banknote className="w-5 h-5 text-emerald-600" />
        </div>
        <h3 className="font-black text-xs uppercase tracking-widest text-slate-400">Monthly Salaries</h3>
      </div>

      <div className="space-y-3">
        {/* Vivek Row */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-blue-50/30 border border-blue-100/20 hover:bg-blue-50/50 transition-colors group">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-tighter mb-1">Vivek</span>
            <div className="flex items-center gap-2">
               {editingPerson === 'Vivek' ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={tempValue}
                      onChange={(e) => setTempValue(e.target.value)}
                      autoFocus
                      className="text-sm font-black px-2 py-1 bg-white border border-blue-200 rounded-lg w-24 outline-none focus:ring-2 focus:ring-indigo-500/20"
                      onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                    />
                    <button onClick={handleSave} className="p-1.5 bg-indigo-600 text-white rounded-lg shadow-sm hover:bg-indigo-700"><Check className="w-4 h-4" /></button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-base font-black text-slate-800">AED {vivekIncome.toLocaleString()}</span>
                    <button onClick={() => handleStartEdit('Vivek', vivekIncome)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-indigo-600 transition-all">
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
            </div>
          </div>
        </div>

        {/* Shefali Row */}
        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-rose-50/20 border border-rose-100/10 hover:bg-rose-50/40 transition-colors group">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-rose-500 uppercase tracking-tighter mb-1">Shefali</span>
            <div className="flex items-center gap-2">
               {editingPerson === 'Shefali' ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={tempValue}
                      onChange={(e) => setTempValue(e.target.value)}
                      autoFocus
                      className="text-sm font-black px-2 py-1 bg-white border border-rose-200 rounded-lg w-24 outline-none focus:ring-2 focus:ring-rose-500/20"
                      onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                    />
                    <button onClick={handleSave} className="p-1.5 bg-rose-600 text-white rounded-lg shadow-sm hover:bg-rose-700"><Check className="w-4 h-4" /></button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-base font-black text-slate-800">AED {shefaliIncome.toLocaleString()}</span>
                    <button onClick={() => handleStartEdit('Shefali', shefaliIncome)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-600 transition-all">
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
            </div>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Household Income</span>
        <span className="text-lg font-black text-slate-900 leading-none">AED {total.toLocaleString()}</span>
      </div>
    </div>
  );
};

export default IncomeInput;
