
import React, { useMemo } from 'react';
import { Expense, Category } from '../types';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend 
} from 'recharts';

interface ExpenseChartsProps {
  expenses: Expense[];
}

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#6366f1', '#94a3b8'];
const PERSON_COLORS = {
  'Vivek': '#4f46e5',
  'Shefali': '#ef4444'
};

const ExpenseCharts: React.FC<ExpenseChartsProps> = ({ expenses }) => {
  const categoryData = useMemo(() => {
    const data: Record<string, number> = {};
    expenses.forEach((ex) => {
      data[ex.category] = (data[ex.category] || 0) + ex.amount;
    });
    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const personData = useMemo(() => {
    const data: Record<string, number> = {};
    expenses.forEach((ex) => {
      data[ex.person] = (data[ex.person] || 0) + ex.amount;
    });
    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const dynamicData = useMemo(() => {
    if (expenses.length === 0) return [];

    // Sort expenses by date
    const sortedExpenses = [...expenses].sort((a, b) => a.date.localeCompare(b.date));
    const firstDate = new Date(sortedExpenses[0].date);
    const lastDate = new Date(sortedExpenses[sortedExpenses.length - 1].date);
    
    // Calculate range in days
    const diffTime = Math.abs(lastDate.getTime() - firstDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    const data: Record<string, number> = {};

    if (diffDays <= 31) {
      // Show daily data for ranges up to a month
      const dates: string[] = [];
      for (let i = 0; i < diffDays; i++) {
        const d = new Date(firstDate);
        d.setDate(d.getDate() + i);
        const dateStr = d.toISOString().split('T')[0];
        dates.push(dateStr);
        data[dateStr] = 0;
      }

      expenses.forEach((ex) => {
        if (data.hasOwnProperty(ex.date)) {
          data[ex.date] += ex.amount;
        }
      });

      return Object.entries(data).map(([date, amount]) => ({
        label: new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        amount
      }));
    } else {
      // Group by month for longer ranges
      expenses.forEach((ex) => {
        const d = new Date(ex.date);
        const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        data[monthKey] = (data[monthKey] || 0) + ex.amount;
      });

      return Object.entries(data).sort().map(([month, amount]) => {
        const [year, m] = month.split('-');
        const date = new Date(parseInt(year), parseInt(m) - 1);
        return {
          label: date.toLocaleDateString(undefined, { month: 'short', year: '2-digit' }),
          amount
        };
      });
    }
  }, [expenses]);

  if (expenses.length === 0) return null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-[350px]">
          <h3 className="text-sm font-bold text-slate-800 mb-4 uppercase tracking-wider">Spending by Category</h3>
          <ResponsiveContainer width="100%" height="90%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <RechartsTooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                formatter={(value: number) => `AED ${value.toFixed(2)}`}
              />
              <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-[350px]">
          <h3 className="text-sm font-bold text-slate-800 mb-4 uppercase tracking-wider">Spending by Person</h3>
          <ResponsiveContainer width="100%" height="90%">
            <PieChart>
              <Pie
                data={personData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {personData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.name === 'Vivek' ? PERSON_COLORS.Vivek : PERSON_COLORS.Shefali} />
                ))}
              </Pie>
              <RechartsTooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                formatter={(value: number) => `AED ${value.toFixed(2)}`}
              />
              <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-[350px]">
        <h3 className="text-sm font-bold text-slate-800 mb-4 uppercase tracking-wider">
          Spending Timeline
        </h3>
        <ResponsiveContainer width="100%" height="90%">
          <BarChart data={dynamicData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <RechartsTooltip 
              cursor={{ fill: '#f8fafc' }}
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
              formatter={(value: number) => `AED ${value.toFixed(2)}`}
            />
            <Bar dataKey="amount" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={24} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ExpenseCharts;
