
import React, { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, FilterX } from 'lucide-react';
import { Expense } from '../types';

interface DateRangeFilterProps {
  startDate: string;
  endDate: string;
  setStartDate: (date: string) => void;
  setEndDate: (date: string) => void;
  onReset: () => void;
  expenses: Expense[];
}

const DateRangeFilter: React.FC<DateRangeFilterProps> = ({ 
  startDate, 
  endDate, 
  setStartDate, 
  setEndDate, 
  onReset,
  expenses
}) => {
  const [viewDate, setViewDate] = useState(new Date());

  const daysInMonth = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const days = new Date(year, month + 1, 0).getDate();
    return { firstDay, days, year, month };
  }, [viewDate]);

  const expenseDates = useMemo(() => {
    const set = new Set<string>();
    expenses.forEach(ex => set.add(ex.date));
    return set;
  }, [expenses]);

  const handlePrevMonth = () => {
    setViewDate(new Date(daysInMonth.year, daysInMonth.month - 1, 1));
  };

  const handleNextMonth = () => {
    setViewDate(new Date(daysInMonth.year, daysInMonth.month + 1, 1));
  };

  const handleDateClick = (day: number) => {
    const selectedDate = new Date(daysInMonth.year, daysInMonth.month, day);
    const dateStr = selectedDate.toLocaleDateString('en-CA'); 
    setStartDate(dateStr);
    setEndDate(dateStr);
  };

  const isSelected = (day: number) => {
    const dateStr = new Date(daysInMonth.year, daysInMonth.month, day).toLocaleDateString('en-CA');
    return startDate === dateStr && endDate === dateStr;
  };

  const hasExpenses = (day: number) => {
    const dateStr = new Date(daysInMonth.year, daysInMonth.month, day).toLocaleDateString('en-CA');
    return expenseDates.has(dateStr);
  };

  const monthName = viewDate.toLocaleString('default', { month: 'long' });

  // Generate calendar grid
  const calendarDays = [];
  for (let i = 0; i < daysInMonth.firstDay; i++) {
    calendarDays.push(<div key={`empty-${i}`} className="aspect-square w-full" />);
  }
  for (let d = 1; d <= daysInMonth.days; d++) {
    const selected = isSelected(d);
    const active = hasExpenses(d);
    calendarDays.push(
      <button
        key={d}
        onClick={() => handleDateClick(d)}
        className={`aspect-square w-full rounded-2xl flex flex-col items-center justify-center relative transition-all text-sm font-black
          ${selected ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-200 scale-105 z-10' : 'text-slate-700 hover:bg-indigo-50'}
        `}
      >
        {d}
        {active && !selected && (
          <div className="absolute bottom-2 w-1.5 h-1.5 bg-indigo-400 rounded-full" />
        )}
      </button>
    );
  }

  return (
    <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 rounded-2xl">
            <CalendarIcon className="w-5 h-5 text-indigo-600" />
          </div>
          <h3 className="font-black text-xs uppercase tracking-widest text-slate-400">Activity Calendar</h3>
        </div>
        {(startDate || endDate) && (
          <button
            onClick={onReset}
            className="flex items-center gap-2 px-4 py-2 text-[10px] font-black uppercase text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-all"
          >
            <FilterX className="w-3.5 h-3.5" />
            Clear Filter
          </button>
        )}
      </div>

      <div className="flex items-center justify-between bg-slate-50/80 p-2.5 rounded-2xl mb-6">
        <button onClick={handlePrevMonth} className="p-2.5 hover:bg-white rounded-xl transition-all shadow-sm hover:shadow-md">
          <ChevronLeft className="w-5 h-5 text-slate-400" />
        </button>
        <span className="font-black text-sm text-slate-800 uppercase tracking-tight">
          {monthName} {daysInMonth.year}
        </span>
        <button onClick={handleNextMonth} className="p-2.5 hover:bg-white rounded-xl transition-all shadow-sm hover:shadow-md">
          <ChevronRight className="w-5 h-5 text-slate-400" />
        </button>
      </div>

      <div className="flex-1 grid grid-cols-7 gap-1">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-[10px] font-black text-slate-300 py-3 uppercase tracking-tighter">{day}</div>
        ))}
        {calendarDays}
      </div>

      {startDate && endDate && startDate === endDate && (
        <div className="mt-6 text-[10px] font-black text-indigo-600 bg-indigo-50/50 p-3 rounded-2xl text-center uppercase tracking-widest border border-indigo-100/50">
          Showing: {new Date(startDate).toLocaleDateString(undefined, { dateStyle: 'full' })}
        </div>
      )}
    </div>
  );
};

export default DateRangeFilter;
