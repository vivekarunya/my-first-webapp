
import React, { useState } from 'react';
import { PenTool, Coins, Save } from 'lucide-react';
import { Category, Person } from '../types';

interface QuickEntryProps {
  selectedDate: string;
  onSave: (name: string, amount: number, category: Category, date: string, person: Person) => void;
}

const QuickEntry: React.FC<QuickEntryProps> = ({ selectedDate, onSave }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>(Category.Food);
  const [person, setPerson] = useState<Person>('Vivek');

  const displayDate = selectedDate || new Date().toLocaleDateString('en-CA');

  const handleQuickSave = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (name.trim() && !isNaN(val) && val > 0) {
      onSave(name, val, category, displayDate, person);
      setName('');
      setAmount('');
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-50 p-2.5 rounded-2xl">
            <Save className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-black text-xs uppercase tracking-widest text-slate-400 leading-none mb-1">Quick Entry</h3>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">
               For <span className="text-indigo-600">{new Date(displayDate).toLocaleDateString(undefined, { dateStyle: 'medium' })}</span>
            </p>
          </div>
        </div>
        
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button 
            type="button"
            onClick={() => setPerson('Vivek')}
            className={`px-3 py-1.5 text-[10px] font-black rounded-lg transition-all ${person === 'Vivek' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Vivek
          </button>
          <button 
            type="button"
            onClick={() => setPerson('Shefali')}
            className={`px-3 py-1.5 text-[10px] font-black rounded-lg transition-all ${person === 'Shefali' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Shefali
          </button>
        </div>
      </div>

      <form onSubmit={handleQuickSave} className="space-y-4">
        <div className="relative group">
          <PenTool className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-indigo-500 transition-colors" />
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="What was it for?"
            className="w-full pl-11 pr-4 py-3 bg-blue-50/20 border border-blue-100 rounded-2xl text-sm font-semibold placeholder:text-slate-300 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all"
            required
          />
        </div>

        <div className="flex gap-3">
          <div className="relative flex-1 group">
            <Coins className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-indigo-500 transition-colors" />
            <input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-11 pr-4 py-3 bg-blue-50/20 border border-blue-100 rounded-2xl text-sm font-black focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all"
              required
            />
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
            className="bg-blue-50/20 border border-blue-100 rounded-2xl px-4 text-xs font-black text-slate-600 outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all cursor-pointer"
          >
            {Object.values(Category).map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-indigo-100 transition-all active:scale-[0.98] flex items-center justify-center gap-3 group"
        >
          <Save className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span>Save Transaction</span>
        </button>
      </form>
    </div>
  );
};

export default QuickEntry;
