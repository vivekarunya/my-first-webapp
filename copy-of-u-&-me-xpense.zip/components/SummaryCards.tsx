
import React from 'react';
import { Expense } from '../types';
import { Wallet, PiggyBank, Landmark, TrendingUp, Users } from 'lucide-react';

interface SummaryCardsProps {
  expenses: Expense[];
  total: number;
  income: number;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ expenses, total, income }) => {
  const balance = income - total;
  const savingsRate = income > 0 ? (balance / income) * 100 : 0;

  const vivekSpent = expenses.filter(e => e.person === 'Vivek').reduce((s, e) => s + e.amount, 0);
  const shefaliSpent = expenses.filter(e => e.person === 'Shefali').reduce((s, e) => s + e.amount, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Income Card */}
        <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 flex flex-col justify-between h-32">
          <div className="flex items-center gap-2.5 text-indigo-600">
            <Landmark className="w-5 h-5" />
            <span className="text-xs font-black uppercase tracking-widest">Monthly Income</span>
          </div>
          <div className="text-3xl font-black text-slate-900 flex items-baseline gap-1">
            <span className="text-sm font-bold text-slate-400">AED</span>
            {income.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
        </div>

        {/* Expenses Card */}
        <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 flex flex-col justify-between h-32">
          <div className="flex items-center gap-2.5 text-rose-500">
            <Wallet className="w-5 h-5" />
            <span className="text-xs font-black uppercase tracking-widest">Total Spent</span>
          </div>
          <div className="text-3xl font-black text-slate-900 flex items-baseline gap-1">
            <span className="text-sm font-bold text-slate-400">AED</span>
            {total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* Balance Card */}
        <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 flex flex-col justify-between h-32">
          <div className="flex items-center gap-2.5 text-emerald-600">
            <PiggyBank className="w-5 h-5" />
            <span className="text-xs font-black uppercase tracking-widest">Net Balance</span>
          </div>
          <div className={`text-3xl font-black flex items-baseline gap-1 ${balance < 0 ? 'text-rose-600' : 'text-slate-900'}`}>
            <span className="text-sm font-bold text-slate-400">AED</span>
            {balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* Savings Card */}
        <div className="bg-white p-6 rounded-3xl border border-blue-100/50 shadow-sm shadow-blue-900/5 flex flex-col justify-between h-32">
          <div className="flex items-center gap-2.5 text-amber-500">
            <TrendingUp className="w-5 h-5" />
            <span className="text-xs font-black uppercase tracking-widest">Savings Rate</span>
          </div>
          <div className="text-3xl font-black text-slate-900 flex items-baseline gap-1">
            {income > 0 ? savingsRate.toFixed(1) : '0'}
            <span className="text-sm font-bold text-slate-400 ml-1">%</span>
          </div>
        </div>
      </div>

      {/* Person Breakdown Bar */}
      <div className="bg-white/80 backdrop-blur-sm p-6 rounded-3xl border border-indigo-100/50 flex flex-col sm:flex-row sm:items-center gap-6 shadow-sm">
        <div className="flex items-center gap-3 text-indigo-900/80 shrink-0">
          <div className="p-2 bg-indigo-50 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
          <span className="text-xs font-black uppercase tracking-widest">Contribution Breakdown</span>
        </div>
        
        <div className="flex-1 flex gap-8 items-center">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Vivek Paid</p>
            <p className="text-lg font-black text-indigo-600 leading-none">AED {vivekSpent.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          </div>
          
          <div className="h-10 w-px bg-slate-100 hidden sm:block"></div>
          
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Shefali Paid</p>
            <p className="text-lg font-black text-rose-500 leading-none">AED {shefaliSpent.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          </div>
          
          <div className="hidden lg:flex flex-1 items-center gap-2 pl-4">
             <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden flex">
                <div 
                  className="bg-indigo-500 transition-all duration-1000" 
                  style={{ width: total > 0 ? `${(vivekSpent / total) * 100}%` : '50%' }}
                />
                <div 
                  className="bg-rose-400 transition-all duration-1000" 
                  style={{ width: total > 0 ? `${(shefaliSpent / total) * 100}%` : '50%' }}
                />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryCards;
