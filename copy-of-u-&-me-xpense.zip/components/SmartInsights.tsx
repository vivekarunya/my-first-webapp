
import React, { useState, useEffect } from 'react';
import { Expense } from '../types';
import { getFinancialInsights } from '../services/geminiService';
import { Lightbulb, RefreshCw, Bot, Sparkles } from 'lucide-react';

interface SmartInsightsProps {
  expenses: Expense[];
  income: number;
}

const SmartInsights: React.FC<SmartInsightsProps> = ({ expenses, income }) => {
  const [insight, setInsight] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const fetchInsights = async () => {
    if (expenses.length === 0) return;
    setLoading(true);
    try {
      const text = await getFinancialInsights(expenses, income);
      setInsight(text);
    } catch (err) {
      setInsight("Failed to load insights. Try adding more data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (expenses.length > 0 && !insight) {
      fetchInsights();
    }
  }, [expenses]);

  return (
    <div className="bg-slate-900 rounded-[2rem] p-8 text-white shadow-2xl shadow-indigo-900/10 relative overflow-hidden h-full flex flex-col">
      {/* Dynamic Background */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-rose-500/5 rounded-full blur-[60px] -ml-24 -mb-24"></div>
      
      <div className="flex items-center justify-between mb-8 relative z-10">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-500/20 p-2.5 rounded-2xl backdrop-blur-sm border border-white/5">
            <Bot className="w-6 h-6 text-indigo-300" />
          </div>
          <div>
            <h3 className="font-black text-lg leading-none mb-1">AI Advisor</h3>
            <p className="text-[10px] font-black uppercase tracking-widest text-indigo-400">Powered by Gemini</p>
          </div>
        </div>
        <button 
          onClick={fetchInsights} 
          disabled={loading || expenses.length === 0}
          className="p-3 hover:bg-white/10 rounded-2xl transition-all disabled:opacity-30 border border-white/5 bg-white/5"
          title="Regenerate Report"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="relative z-10 flex-1">
        {expenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-8">
            <Sparkles className="w-12 h-12 text-indigo-400 opacity-30" />
            <p className="text-indigo-200 text-sm font-bold italic px-4">
              "Add your first few transactions to unlock personalized AI-driven household strategy."
            </p>
          </div>
        ) : loading ? (
          <div className="space-y-4 py-4">
            <div className="h-4 bg-white/5 rounded-full animate-pulse w-3/4"></div>
            <div className="h-4 bg-white/5 rounded-full animate-pulse w-full"></div>
            <div className="h-4 bg-white/5 rounded-full animate-pulse w-5/6"></div>
            <div className="h-4 bg-white/5 rounded-full animate-pulse w-2/3"></div>
          </div>
        ) : (
          <div className="text-sm leading-relaxed text-indigo-50/90 font-medium space-y-4 overflow-y-auto max-h-[400px] pr-2 custom-scrollbar">
            {insight.split('\n').map((para, i) => para.trim() && (
              <p key={i} className="mb-4 last:mb-0 bg-white/5 p-4 rounded-2xl border border-white/5">{para}</p>
            ))}
          </div>
        )}
      </div>

      <div className="mt-8 pt-6 border-t border-white/5 flex items-start gap-3 relative z-10">
        <Lightbulb className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-[10px] text-indigo-300 font-black leading-normal uppercase tracking-tight">
          Advice is based on current activity. Always consult a professional for major financial decisions.
        </p>
      </div>
    </div>
  );
};

export default SmartInsights;
