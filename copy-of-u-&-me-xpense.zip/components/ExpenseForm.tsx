
import React, { useState, useEffect } from 'react';
import { Expense, Category, Person } from '../types';
import { X, Calendar as CalendarIcon, Tag, Coins, PenTool, User } from 'lucide-react';

interface ExpenseFormProps {
  expense?: Expense;
  onClose: () => void;
  onSubmit: (expense: Omit<Expense, 'id'>) => void;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({ expense, onClose, onSubmit }) => {
  const [name, setName] = useState(expense?.name || '');
  const [amount, setAmount] = useState(expense?.amount?.toString() || '');
  const [category, setCategory] = useState<Category>(expense?.category || Category.Food);
  const [date, setDate] = useState(expense?.date || new Date().toISOString().split('T')[0]);
  const [person, setPerson] = useState<Person>(expense?.person || 'Vivek');

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = 'unset'; };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !amount || !category || !date) return;
    onSubmit({
      name,
      amount: parseFloat(amount),
      category,
      date,
      person,
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300" 
        onClick={onClose}
      />
      
      {/* Modal Container */}
      <div className="relative bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="px-8 py-8 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
          <div>
             <h2 className="text-2xl font-black text-slate-900 leading-none mb-2">
                {expense ? 'Modify Expense' : 'Log New Expense'}
              </h2>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Transaction Details</p>
          </div>
          <button 
            onClick={onClose} 
            className="p-3 bg-white hover:bg-rose-50 hover:text-rose-500 rounded-2xl transition-all shadow-sm ring-1 ring-slate-100"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {/* Member Toggle */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <User className="w-3.5 h-3.5" />
              Whose transaction is this?
            </label>
            <div className="flex p-1.5 bg-slate-100 rounded-[1.25rem]">
              <button
                type="button"
                onClick={() => setPerson('Vivek')}
                className={`flex-1 py-3 text-xs font-black rounded-xl transition-all ${person === 'Vivek' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Vivek
              </button>
              <button
                type="button"
                onClick={() => setPerson('Shefali')}
                className={`flex-1 py-3 text-xs font-black rounded-xl transition-all ${person === 'Shefali' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Shefali
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <PenTool className="w-3.5 h-3.5" />
              Description
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Weekly Groceries"
              className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all font-bold text-slate-800 placeholder:text-slate-300"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <Coins className="w-3.5 h-3.5" />
                Amount (AED)
              </label>
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all font-black text-slate-800"
                required
              />
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <Tag className="w-3.5 h-3.5" />
                Category
              </label>
              <div className="relative">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as Category)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all font-black text-slate-800 appearance-none cursor-pointer"
                  required
                >
                  {Object.values(Category).map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <Tag className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <CalendarIcon className="w-3.5 h-3.5" />
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400 outline-none transition-all font-bold text-slate-800"
              required
            />
          </div>

          <div className="pt-6 flex gap-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-100 rounded-2xl font-black text-slate-500 hover:bg-slate-50 transition-all uppercase tracking-widest text-xs"
            >
              Discard
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-95 uppercase tracking-widest text-xs"
            >
              {expense ? 'Update Record' : 'Confirm Entry'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExpenseForm;
